( function($) {
	$( 'input[name="s"]' )
		.typeahead( {
			name: 'search',
			remote: wp_typeahead.ajaxurl + '?action=ajax_search&fn=get_ajax_search&terms=%QUERY',
			template: [
				'<div class=""><h5><a href="{{url}}">{{value}}</a></h5><p>{{postContent}}</p></div>',
			].join(''),
			engine: Hogan
		} )
		.keypress( function(e) {
			if ( 13 == e.which ) {
				$(this).parents( 'form' ).submit();
				return false;
			}
		}
	);
} )(jQuery);
